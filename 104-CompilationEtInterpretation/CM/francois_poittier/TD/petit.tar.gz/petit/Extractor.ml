(* This script is not part of the compiler. It is used by "make live". *)

(* Usage:  ocaml str.cma Extractor.ml MARK
   Effect: look for two input lines that contain MARK
           echo the text comprised between these lines
   Note:   supports more than two lines that contain MARK
             echoing is turned on/off at each MARK
           MARK may be a regexp
*)
let () =
  (* We expect one argument, a mark (e.g. FOO). It can be a regexp. *)
  assert (Array.length Sys.argv = 2);
  let mark = Str.regexp Sys.argv.(1) in
  (* This auxiliary function detects a line that contains the mark. *)
  let matches line =
    try
      let (_ : int) = Str.search_forward mark line 0 in
      true
    with Not_found ->
      false
  in
  (* Initially, text is not echoed. *)
  let mode = ref false in
  try
    while true do
      (* Read an input line. *)
      let line = input_line stdin in
      (* If this line contains the mark, then it is not printed, and the
	 current mode changes. *)
      if matches line then
	mode := not !mode
      (* If this line does not contain the mark, then it is echoed, if
	 the current mode is true. *)
      else if !mode then
	Printf.printf "%s\n" line
    done
  with End_of_file ->
    flush stdout
