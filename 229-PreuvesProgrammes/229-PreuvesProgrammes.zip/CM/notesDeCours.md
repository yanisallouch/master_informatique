* slide juste avant la 19 en exercice, "faute transitoire"
* slide 24 preuve par récurrence