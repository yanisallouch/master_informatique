#include <unistd.h>

void calcul (int sec);
