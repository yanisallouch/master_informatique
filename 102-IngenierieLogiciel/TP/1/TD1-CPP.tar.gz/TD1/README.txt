Code créé par Guillaume Fabre (guillaume.fabre03@etu.umontpellier.fr)

Nécessite un compilateur supportant la norme de 2011.
La majeure partie du code se trouve dans les .hhp, l'utilisation de templates l'oblige.

!!! Le Makefile affichera "SUCCES" même en cas d'erreur ou de warning (mais affichera également les erreurs/warnings) !!! 