﻿namespace ClassLibrary1
{
    interface IGeometrique
    {
        string getNom();
        double getAire();
        double getPerimetre();
        double getVolume();
    }
}
