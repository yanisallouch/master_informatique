package fr.umfds.TPtestServicesREST;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "brainstorm")
public class Brainstorm implements Comparable<Brainstorm> {
	private String nom;
	private int identifiant;
	private List<Idea>ideas;  
	
	public Brainstorm() {
		super();
		// TODO Auto-generated constructor stub
	}
		

	public Brainstorm(String nom, int identifiant, List<Idea> ideas) {
		super();
		this.nom = nom;
		this.identifiant = identifiant;
		this.ideas = ideas;
	}


	public String getNom() {
		return this.nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getIdentifiant() {
		return this.identifiant;
	}
	public void setIdentifiant(int identifiant) {
		this.identifiant = identifiant;
	}
	
	 public List<Idea> getIdeas() {
		return this.ideas;
	}

	public void setIdeas(List<Idea> ideas) {
		this.ideas = ideas;
	}


	@Override
	 public int compareTo(Brainstorm brainstorm2) {
		 return this.getNom().compareTo(brainstorm2.getNom());
	 }
	
	
}
