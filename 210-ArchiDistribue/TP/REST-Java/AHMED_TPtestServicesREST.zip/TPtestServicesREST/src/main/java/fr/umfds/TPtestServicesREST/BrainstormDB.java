package fr.umfds.TPtestServicesREST;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.NotFoundException;

public class BrainstormDB {
	
	private static List <Brainstorm> brainstorms= new ArrayList<>();
	public BrainstormDB() {
		super();

	}

	public List<Brainstorm> getBrainstormsfromDB(){
		brainstorms.add(new Brainstorm("nom2",2,new ArrayList<>()));
		brainstorms.add(new Brainstorm("nom1",1,new ArrayList<>()));
		brainstorms.add(new Brainstorm("nom3",3,new ArrayList<>()));
		return brainstorms;
	}
	
	public void addBrainstormToDB(Brainstorm brainstorm) {
		brainstorms.add(brainstorm);
	}
	
	public String putIdea(int id,String contentIdea)throws NotFoundException {
		Idea idea=new Idea(contentIdea);
		for(Brainstorm brainstorm : brainstorms) {
			if(brainstorm.getIdentifiant()==id) {
				brainstorm.getIdeas().add(idea);
				return brainstorm.getIdeas().get(brainstorm.getIdeas().size()-1).getContent();
			}
		}
		throw new NotFoundException();
	}
	
	public List<Idea> getIdeaOfBrainstormFromDB(int id) throws NotFoundException{
		for(Brainstorm brainstorm:brainstorms) {
			if(brainstorm.getIdentifiant()==id) {
				return brainstorm.getIdeas();
			}
		}
		throw new NotFoundException();
	}
	
	// utilisé avant la réalisation de la partie Test d’intégration, mock, et injection
/*
	public static List<Brainstorm> getBrainstormsfromDB2(){
		brainstorms = new ArrayList<>();
		brainstorms.add(new Brainstorm("nom2",2,new ArrayList<>()));
		brainstorms.add(new Brainstorm("nom1",1,new ArrayList<>()));
		brainstorms.add(new Brainstorm("nom3",3,new ArrayList<>()));
		return brainstorms;
	}
*/
}




