package fr.umfds.TPtestServicesREST;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


@Path("/brainstorms") @Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
public class BrainstormRessource {
	
	@Inject 
	private BrainstormDB brainstormDB;
	
	
	public BrainstormRessource() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BrainstormRessource(BrainstormDB brainstormDB) {
		super();
		this.brainstormDB =brainstormDB;
	} 
	
	@GET
	public List<Brainstorm> getBrainstorms(){
		List <Brainstorm> brainstorms = this.brainstormDB.getBrainstormsfromDB();
		Collections.sort(brainstorms);
		return brainstorms;
	}
	
	 @GET  
	 @Path("brainstormid-{id}")   
	 public Brainstorm getBrainstorm(@PathParam("id")int brainstormId)throws NotFoundException {
		 List <Brainstorm> brainstorms = this.brainstormDB.getBrainstormsfromDB();
		 
		 for(Brainstorm brainstorm : brainstorms) {
			 if(brainstorm.getIdentifiant()==brainstormId) {
				return brainstorm;
			}
		 }
		 throw new NotFoundException();
	 }
	 @POST 
	 @Consumes(MediaType.APPLICATION_JSON)
	 public Response addBrainstorm(Brainstorm brainstorm) {
		 this.brainstormDB.addBrainstormToDB(brainstorm); 
		 return Response.ok().status(Status.CREATED).build();
	}
	 
	 @PUT 
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Path("{id}/ideas")  
	 public Response addIdeaToBrainstorm(@PathParam("id") int id,String contentIdea) {
		this.brainstormDB.putIdea(id, contentIdea);
		return Response.ok().status(Status.OK).build();
				
	}
	 @GET   @Path("{id}/ideas")   
	 public Response getIdeasOfBrainstorm(@PathParam("id")int brainstormId) {
		 List <Idea> ideas = this.brainstormDB.getIdeaOfBrainstormFromDB(brainstormId);
		 return Response.ok(ideas).status(Status.OK).build();
	 }
	 
	 
	// utilisé avant la réalisation de la partie Test d’intégration, mock, et injection
	
/*	@GET
	public List<Brainstorm> getBrainstorms(){
		List <Brainstorm> brainstorms = BrainstormDB.getBrainstormsfromDB();
		Collections.sort(brainstorms);
		return brainstorms;
	}
*/
}
