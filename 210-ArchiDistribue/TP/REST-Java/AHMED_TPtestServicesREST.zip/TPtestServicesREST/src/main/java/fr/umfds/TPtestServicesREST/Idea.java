package fr.umfds.TPtestServicesREST;

public class Idea {
 
	private String content;
	
	public Idea() {
		// TODO Auto-generated constructor stub
	}

	public Idea(String content) {
		super();
		this.content = content;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
}
