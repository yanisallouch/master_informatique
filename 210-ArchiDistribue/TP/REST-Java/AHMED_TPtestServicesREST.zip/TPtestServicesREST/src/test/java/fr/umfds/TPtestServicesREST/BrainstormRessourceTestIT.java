package fr.umfds.TPtestServicesREST;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.test.JerseyTest;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;


public class BrainstormRessourceTestIT extends JerseyTest {

	@Override
	protected Application configure() {
		ResourceConfig resourceConfig = new ResourceConfig(BrainstormRessource.class);
	    resourceConfig.property(LoggingFeature.LOGGING_FEATURE_LOGGER_LEVEL_SERVER, Level.WARNING.getName());
	    BrainstormDB dbMock =Mockito.mock(BrainstormDB.class);
	    resourceConfig.register(new AbstractBinder() {
	        @Override
	        protected void configure() {
	            List<Brainstorm> l=Arrays.asList(new Brainstorm("nomMock1",1,new ArrayList<>()),new Brainstorm("nomMock2",2,new ArrayList<>()),new Brainstorm("nomMock3",3,new ArrayList<>()));     
	            Mockito.when(dbMock.getBrainstormsfromDB()).thenReturn(l);
	            
	            List<Idea>ideas=Arrays.asList(new Idea("content idea 1"),new Idea("content idea 2"));
	            Mockito.when(dbMock.getIdeaOfBrainstormFromDB(1)).thenReturn(ideas);
	            bind(dbMock).to(BrainstormDB.class);
	       }
	    });
	     return resourceConfig;
	}
	
	
	@Test
    public void testGetBrainstorms() {
        // Given

        // When
        Response response = target("/brainstorms").request(MediaType.APPLICATION_JSON_TYPE).get();

        // Then
        Assert.assertEquals("Http Response should be 200: ", Status.OK.getStatusCode(), response.getStatus());
        List<Brainstorm> readEntities = response.readEntity(new GenericType<List<Brainstorm>>() {});
        Assert.assertNotNull(readEntities);
        Assert.assertEquals(3, readEntities.size());
        Assert.assertTrue(readEntities.stream().anyMatch(current -> current.getIdentifiant()==1));
    }
	
	@Test
	public void shouldReturnNullOnInexistentId() {
		// Given
		int id = 8;
        // When
        Response response = target("/brainstorms/brainstormid-"+id).request(MediaType.APPLICATION_JSON_TYPE).get();

        // Then
        Assert.assertEquals("Http Response should be 404: ", Status.NOT_FOUND.getStatusCode(), response.getStatus());
        Brainstorm readEntities = response.readEntity(new GenericType<Brainstorm>() {});
        Assert.assertNull(readEntities);
	}
	
	@Test
	public void shouldReturnOkOnExistentId() {
		// Given
		int id = 1;
        // When
        Response response = target("/brainstorms/brainstormid-"+id).request(MediaType.APPLICATION_JSON_TYPE).get();

        // Then
        Assert.assertEquals("Http Response should be 200: ", Status.OK.getStatusCode(), response.getStatus());
        Brainstorm readEntities = response.readEntity(new GenericType<Brainstorm>() {});
        Assert.assertNotNull(readEntities);
	}
	
	@Test
	public void addBrainstormTest() {
		// Given
		Brainstorm brainstorm = new Brainstorm("nom4",4,new ArrayList<>());
        // When
        Response response = target("/brainstorms").request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.json(brainstorm), Response.class);

        // Then
        Assert.assertEquals("Http Response should be 201: ", Status.CREATED.getStatusCode(), response.getStatus());
       
	}
	
	@Test
	public void shouldputIdea() {
		// Given
		int id = 1;
		String ideas="ideas";
		String contentIdea="content of idea";
        // When
        Response response = target("/brainstorms/"+id+"/"+ideas).request(MediaType.APPLICATION_JSON).put(Entity.entity(contentIdea, MediaType.APPLICATION_JSON));

        // Then
        Assert.assertEquals("Http Response should be 200: ", Status.OK.getStatusCode(), response.getStatus());
       
	}
	@Test
    public void testGetIdeaFromBrainstorm() {
        // Given
		int id=1;
        // When
        Response response = target("/brainstorms/"+id+"/ideas").request(MediaType.APPLICATION_JSON_TYPE).get();

        // Then
        Assert.assertEquals("Http Response should be 200: ", Status.OK.getStatusCode(), response.getStatus());
        List<Idea> readEntities = response.readEntity(new GenericType<List<Idea>>() {});
        Assert.assertNotNull(readEntities);
        Assert.assertEquals(2, readEntities.size());
        Assert.assertTrue(readEntities.stream().anyMatch(current -> current.getContent().equals("content idea 1")));
        Assert.assertTrue(readEntities.stream().anyMatch(current -> current.getContent().equals("content idea 2")));

    }


}
