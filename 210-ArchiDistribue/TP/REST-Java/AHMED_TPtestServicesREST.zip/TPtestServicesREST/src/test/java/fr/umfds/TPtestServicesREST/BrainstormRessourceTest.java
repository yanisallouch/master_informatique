package fr.umfds.TPtestServicesREST;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class BrainstormRessourceTest {

	private Brainstorm brainstorm1 ;
	private Brainstorm brainstorm2 ;
	private Brainstorm brainstorm3 ;
	
	private BrainstormDB brainstormDB;
	private BrainstormRessource brainstormRessource;
	
	@BeforeEach
	public void SetUp() {
		this.brainstorm1 = new Brainstorm("nom1",1,new ArrayList<>());
		this.brainstorm2 = new Brainstorm("nom2",2,new ArrayList<>());
		this.brainstorm3 = new Brainstorm("nom3",3,new ArrayList<>());
		
		this.brainstormDB =Mockito.mock(BrainstormDB.class);
		this.brainstormRessource = new BrainstormRessource(this.brainstormDB);
	}
	
	@Test
	public void getBrainstormsIsNotNull() {
		//Given
		List<Brainstorm>braistromsExpected = new ArrayList<>();
		braistromsExpected.add(this.brainstorm1);
		braistromsExpected.add(this.brainstorm2);
		braistromsExpected.add(this.brainstorm3);
		//When
		Mockito.when(this.brainstormDB.getBrainstormsfromDB()).thenReturn(braistromsExpected);
		//Then
		assertAll(
					()->assertNotNull(this.brainstormRessource.getBrainstorms()),
					()->assertTrue(this.brainstormRessource.getBrainstorms().size()>0)
				 );
	}
	
	@Test
	public void getBrainstormsIsSorted() {
		//Given
		List<Brainstorm>braistromsExpected = new ArrayList<>();
		braistromsExpected.add(this.brainstorm1);
		braistromsExpected.add(this.brainstorm2);
		braistromsExpected.add(this.brainstorm3);
		
		List<Brainstorm>braistromsUnsorted = new ArrayList<>();
		braistromsUnsorted.add(this.brainstorm3);
		braistromsUnsorted.add(this.brainstorm2);
		braistromsUnsorted.add(this.brainstorm1);
		
		
		// When
		Mockito.when(this.brainstormDB.getBrainstormsfromDB()).thenReturn(braistromsUnsorted);
		List<Brainstorm>brainstorms=this.brainstormRessource.getBrainstorms();
		
		//then
		assertArrayEquals(braistromsExpected.toArray(),brainstorms.toArray());
		
	}
	
	
	// utilisé avant la réalisation de la partie Test d’intégration, mock, et injection
	/*
	@Test
	public void getBrainstormsIsNotNull() {
		//Given
		BrainstormRessource brainstormRessource = new BrainstormRessource();
		//When
		//Then
		assertAll(
					()->assertNotNull(brainstormRessource.getBrainstorms()),
					()->assertTrue(brainstormRessource.getBrainstorms().size()>0)
				 );
	}
	 
	@Test
	public void getBrainstormsIsSorted() {
		//Given
		Brainstorm brainstorm1 = new Brainstorm("nom1",1,new ArrayList<>());
		Brainstorm brainstorm2 = new Brainstorm("nom2",2,new ArrayList<>());
		Brainstorm brainstorm3 = new Brainstorm("nom3",3,new ArrayList<>());
		
		List<Brainstorm>braistromsExpected = new ArrayList<>();
		braistromsExpected.add(brainstorm1);
		braistromsExpected.add(brainstorm2);
		braistromsExpected.add(brainstorm3);
		
		List<Brainstorm>braistromsUnsorted = new ArrayList<>();
		braistromsUnsorted.add(brainstorm3);
		braistromsUnsorted.add(brainstorm2);
		braistromsUnsorted.add(brainstorm1);
		
		MockedStatic<BrainstormDB>brainstormDBMock = Mockito.mockStatic(BrainstormDB.class);
		BrainstormRessource brainstormRessource2= new BrainstormRessource();
		
		// When
		brainstormDBMock.when(BrainstormDB::getBrainstormsfromDB).thenReturn(braistromsUnsorted);
		List<Brainstorm>brainstorms=brainstormRessource2.getBrainstorms();
		
		//then
		assertArrayEquals(braistromsExpected.toArray(),brainstorms.toArray());
		
	}
*/
}
