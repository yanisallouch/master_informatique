mongoimport --db SUPERVENTES --collection membres --file membres.json --jsonArray --drop
mongoimport --db SUPERVENTES --collection produits --file produits.json --jsonArray --drop
mongoimport --db SUPERVENTES --collection marques --file marques.json --jsonArray --drop
