package question8hash;

public class Pair<T1, T2> {
	public T1 x;
	public T2 y;
	
	public Pair(T1 x, T2 y) {
		super();
		this.x = x;
		this.y = y;
	}

}
