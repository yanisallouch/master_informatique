package question3;

public class Runner {

	public static void main(String[] args) throws Exception {
		Join1.main(null);
		GroupBy2.main(null);
		
		
	}

}
