import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

class CompositeKeyOrderedStocks implements WritableComparable<CompositeKeyOrderedStocks>{
	public String iddatesnapshot;
	public String identrepot;
	public String idproduit;

	public CompositeKeyOrderedStocks() {
		super();
	}


	public CompositeKeyOrderedStocks(String iddatesnapshot, String identrepot, String idproduit) {
		super();
		this.iddatesnapshot = iddatesnapshot;
		this.identrepot = identrepot;
		this.idproduit = idproduit;
	}


	@Override
	public void readFields(DataInput arg0) throws IOException {
		this.iddatesnapshot =  arg0.readUTF();
		this.identrepot =  arg0.readUTF();
		this.idproduit =  arg0.readUTF();
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		arg0.writeUTF(iddatesnapshot);
		arg0.writeUTF(identrepot);
		arg0.writeUTF(idproduit);
	}

	@Override
	public int compareTo(CompositeKeyOrderedStocks arg0) {
		int compare = iddatesnapshot.compareTo(arg0.iddatesnapshot);
		if(compare == 0) {
			return identrepot.compareTo(arg0.identrepot);
		}
		return compare;
	}
	
	public String toString() {
		return this.iddatesnapshot + "," + this.identrepot + "," + this.idproduit ;
	}
}

class CompositeValueOrderedStocks implements WritableComparable<CompositeValueOrderedStocks>{
	public String stock;
	public String qteSortie;

	public CompositeValueOrderedStocks() {
		super();
	}

	public CompositeValueOrderedStocks(String stock, String qteSortie) {
		super();
		this.stock = stock;
		this.qteSortie = qteSortie;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		this.stock =  arg0.readUTF();
		this.qteSortie =  arg0.readUTF();
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		arg0.writeUTF(stock);
		arg0.writeUTF(qteSortie);
	}
	
	public String toString() {
		return this.stock + "," + this.qteSortie ;
	}

	@Override
	public int compareTo(CompositeValueOrderedStocks arg0) {
		int cmp = stock.compareTo(arg0.stock);
		if(cmp == 0) {
			return qteSortie.compareTo(arg0.qteSortie);
		}
		return cmp;
	}
}

//=========================================================================
//MAPPER
//=========================================================================

class MapOrderedStocks extends Mapper<LongWritable, Text, CompositeKeyOrderedStocks, CompositeValueOrderedStocks> {
	
	private final static String emptyWords[] = { "" };
	
	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		
		String line = value.toString().trim();
		String[] columns = line.split(",");
		CompositeKeyOrderedStocks cleComposite = null;
		CompositeValueOrderedStocks valeurComposite = null;

		if (key.equals(new LongWritable(0)) || Arrays.equals(columns, emptyWords)) {
			return;
		}
		if (columns.length <= 4) {
			if(columns[0].equals("2")) {
				// 2 => identifiant date
				cleComposite = new CompositeKeyOrderedStocks(
						columns[0],
						columns[1],
						columns[2]);
				valeurComposite = new CompositeValueOrderedStocks(
						columns[3],
						columns[4]);
			}
			else {
				return;
			}
		}
		else {
//			System.out.println("Column length is "+ columns.length);
			return;
		}
		
		context.write(cleComposite, valeurComposite); // 
	}
}

//=========================================================================
//REDUCER
//=========================================================================

class ReduceOrderedStocks extends Reducer<CompositeKeyOrderedStocks, CompositeValueOrderedStocks, Text, IntWritable> {

	@Override
	public void reduce(CompositeKeyOrderedStocks key, Iterable<CompositeValueOrderedStocks> values, Context context)
			throws IOException, InterruptedException {

		String idEntrepot = "";
		ArrayList<Integer> stocks = new ArrayList<Integer>();
//		ArrayList<Integer> qteSortie = new ArrayList<Integer>();

		int sum = 0;
		idEntrepot = key.identrepot + "-";

		for (CompositeValueOrderedStocks val : values){
			stocks.add(Integer.parseInt(val.stock));
//			qteSortie.add(Integer.parseInt(val.qteSortie));
		}

		for (Integer integer : stocks) {
			sum += integer;
		}

		context.write(new Text(idEntrepot), new IntWritable(sum));
	}

}

public class OrderedStocksDay {
	private static final String INPUT_PATH = "input-orderedStocksDay/"; // dimensions
	private static final String OUTPUT_PATH = "output/orderedStocksDay-";
	private static final Logger LOG = Logger.getLogger(GroupByProduits.class.getName());

	static {
		System.setProperty("java.util.logging.SimpleFormatter.format", "%5$s%n%6$s");

		try {
			FileHandler fh = new FileHandler("out.log");
			fh.setFormatter(new SimpleFormatter());
			LOG.addHandler(fh);
		} catch (SecurityException | IOException e) {
			System.exit(1);
		}
	}

	/**
	 * Quels sont les entrep�ts ayant le plus de produits en stock � un jour donn� ?
	 */
	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();
		conf.set("fs.file.impl", "com.conga.services.hadoop.patch.HADOOP_7682.WinLocalFileSystem");
		
		Job job = new Job(conf, "Requete-11-DW");
		
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);

		job.setMapOutputKeyClass(CompositeKeyOrderedStocks.class);
		job.setMapOutputValueClass(CompositeValueOrderedStocks.class);
		
		job.setMapperClass(MapOrderedStocks.class);
		job.setReducerClass(ReduceOrderedStocks.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(INPUT_PATH));
		FileOutputFormat.setOutputPath(job, new Path(OUTPUT_PATH + Instant.now().getEpochSecond()));

		job.waitForCompletion(true);
	}
	
}
