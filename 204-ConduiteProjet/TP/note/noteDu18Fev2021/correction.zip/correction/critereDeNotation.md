# Aspect 1

Vous allez fournir une évaluation sur 4 blocs, chaque bloc vaut 5 points. 


En fonction de l'absence de critères ou de toutes autres erreurs que vous décelez, retirer 1, 2 voire 5 points.

Justifier votre note en commentaire (sur chacun des 4 blocs) en expliquant à chaque fois pourquoi vous retirez les points.

=======

A/ 5 points : modifications du planning pour intégrer la queston1 de l'énoncé

 - on peut lire 100% achevé sur les premières taches 

- les taches achevées sont cohérentes dans l'enchainement (pas de retour en arrière)

- toujours avec 720h/h

- aucune tache sur la semaine d'isolement

- ghost prévisionnel + ghost glissant présents

B/ 5 points pour le pert

- enchainement cohérent

- visualisation dans le PERT cohérente

- bonne gestion des éventuelles tâches splitées 

C/ 5 points pour les ressources

- ajout d'un second analyste programmeur (même salaire que l'AP)

- tout le monde sous les 100% puis 80% (1 point en moins par débordement)

D/ 5 points pour le GANTT

- affectation cohérente (pas d'AP dans la conception ou d'utilisateur hors des tests)

- délai du projet inférieur ou égal au 31 mars

- planning des ressources serré (pas de gros trous plusieurs fois dans la semaine)